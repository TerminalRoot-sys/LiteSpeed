/*****************************************************************************
*    Open LiteSpeed is an open source HTTP server.                           *
*    Copyright (C) 2013  LiteSpeed Technologies, Inc.                        *
*                                                                            *
*    This program is free software: you can redistribute it and/or modify    *
*    it under the terms of the GNU General Public License as published by    *
*    the Free Software Foundation, either version 3 of the License, or       *
*    (at your option) any later version.                                     *
*                                                                            *
*    This program is distributed in the hope that it will be useful,         *
*    but WITHOUT ANY WARRANTY; without even the implied warranty of          *
*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the            *
*    GNU General Public License for more details.                            *
*                                                                            *
*    You should have received a copy of the GNU General Public License       *
*    along with this program. If not, see http://www.gnu.org/licenses/.      *
*****************************************************************************/
#include "httplistenerlist.h"
#include <http/httplistener.h>
#include <http/vhostmap.h>

#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>

    static int stopListener( void * pListener )
    {   ((HttpListener*)pListener)->stop(); return 0;  }

    static int suspendListener( void * pListener )
    {   ((HttpListener*)pListener)->suspend(); return 0;  }

    static int suspendSSLListener( void * pListener )
    {
        if ( ((HttpListener*)pListener)->isSSL() )
            ((HttpListener*)pListener)->suspend();
        return 0;
    }

    static int resumeListener( void * pListener )
    {
        ((HttpListener*)pListener)->resume();
        return 0;
    }

    static int resumeSSLListener( void * pListener )
    {
        if ( ((HttpListener*)pListener)->isSSL() )
            ((HttpListener*)pListener)->resume();
        return 0;
    }

    static int resumeButSSLListener( void * pListener )
    {
        if ( !((HttpListener*)pListener)->isSSL())
            ((HttpListener*)pListener)->resume();
        return 0;
    }

    static int endConfigListener( void * pListener )
    {
        ((HttpListener*)pListener)->endConfig();
        return 0;
    }


HttpListenerList::HttpListenerList()
{
}

HttpListenerList::~HttpListenerList()
{
    release_objects();
}

static int s_compare( const void * p1, const void * p2 )
{
    return strcmp( (*((HttpListener**)p1))->getName(),
                   (*((HttpListener**)p2))->getName() );
}
static int f_compare( const void * p1, const void * p2 )
{
    return strcmp( (const char *)p1,
                   ((HttpListener*)p2)->getName() );
}

int HttpListenerList::add( HttpListener * pListener )
{
    assert( pListener != NULL );
    push_back( pListener );
    sort( s_compare );
    return 0;
}

int HttpListenerList::remove( HttpListener * pListener )
{
    assert( pListener != NULL );
    iterator iter = bfind( pListener->getName(), f_compare );
    if ( iter != end() )
    {
        erase( iter );
        sort( s_compare );
    }
    return 0;
}

//HttpListener* HttpListenerList::get( const char * pName ) const
//{
//    if ( pName == NULL )
//        return NULL;
//    iterator iter = bfind( pName, f_compare );
//    if ( iter == end() )
//        return NULL;
//    else
//        return (*iter);
//}

HttpListener* HttpListenerList::get( const char * pName, const char * pAddr )
{
    iterator iter;
    if ( pName )
    {
        iter = bfind( pName, f_compare );
        if ( iter != end() )
            return *iter;
    }
    if ( pAddr )
    {
        iter = bfind( pAddr, f_compare );
        if ( iter != end() )
        {
            HttpListener * p = *iter;
            erase( iter );
            p->setName( pName );
            push_back( p );
            sort( s_compare );
            return p;
        }
    }
    return NULL;
}


void HttpListenerList::stopAll()
{
    for_each( begin(), end(), stopListener );
}

void HttpListenerList::suspendAll()
{
    for_each( begin(), end(), suspendListener );
}

void HttpListenerList::suspendSSL()
{
    for_each( begin(), end(), suspendSSLListener );
}

void HttpListenerList::resumeAll()
{
    for_each( begin(), end(), resumeListener );
}

void HttpListenerList::resumeSSL()
{
    for_each( begin(), end(), resumeSSLListener );
}

void HttpListenerList::resumeAllButSSL()
{
    for_each( begin(), end(), resumeButSSLListener );
}

void HttpListenerList::endConfig()
{
    for_each( begin(), end(), endConfigListener );
}

void HttpListenerList::clear()
{
    release_objects();
}

void HttpListenerList::passListeners()
{
    int startfd = 300;
    for( iterator iter = begin(); iter != end(); ++iter )
    {
        dup2( (*iter)->getfd(), startfd );
        ++startfd;
    }
    close( startfd );
}


void HttpListenerList::recvListeners()
{
    int         startfd = 300;
    char        achSockAddr[128];
    socklen_t   len;
    while( 1 )
    {
        len = 128;
        if ( getpeername( startfd, (struct sockaddr *)achSockAddr, &len ) != -1 )
            break;      // Must not be connected
        len = 128;
        if ( getsockname( startfd, (struct sockaddr *)achSockAddr, &len ) == -1 )
            break;      // Must be a server socket
        if ( ((struct sockaddr *)achSockAddr)->sa_family != PF_UNIX )
        {
            int fd = dup( startfd );
            HttpListener * pListener = new HttpListener();
            pListener->assign( fd, (struct sockaddr *)achSockAddr );
            push_back( pListener );
            sort( s_compare );
        }
        close( startfd );
        ++startfd;
    }
}



void HttpListenerList::moveNonExist( HttpListenerList& rhs )
{
    for( iterator iter = rhs.begin(); iter != rhs.end(); )
    {
        if ( bfind( (*iter)->getName(), f_compare ) == end() )
        {
            add( *iter );
            rhs.erase( iter );
        }
        else
            ++iter;
    }
}

void HttpListenerList::removeVHostMappings( HttpVHost * pVHost)
{
    for( iterator iter = begin(); iter != end(); ++iter )
    {
        (*iter)->getVHostMap()->removeVHost( pVHost );
    }
}

int HttpListenerList::writeRTReport( int fd )
{
    return 0;
}

int HttpListenerList::writeStatusReport( int fd )
{
    iterator iter;
    iterator iterEnd = end();
    char achBuf[1024];
    for( iter = begin(); iter != iterEnd; ++iter )
    {
        if ( (*iter)->writeStatusReport( fd ) == -1 )
            return -1;
    }
    return 0;
}

void HttpListenerList::releaseUnused()
{
    iterator iter;
    for( iter = begin(); iter != end();  )
    {
        (*iter)->stop();
        if ( (*iter)->getVHostMap()->getRef() <= 0 )
        {
            delete (*iter );
            erase( iter );
        }
        else
        {
            ++iter;
        }
    }
}

int HttpListenerList::saveInUseListnersTo( HttpListenerList& rhs )
{
    int add = 0;
    iterator iter;
    for( iter = begin(); iter != end();  )
    {
        (*iter)->stop();
        if ( (*iter)->getVHostMap()->getRef() <= 0 )
        {
            delete ( *iter );
        }
        else
        {
            rhs.add( *iter );
            add++;
        }
        erase( iter );
    }
    return add;
}




