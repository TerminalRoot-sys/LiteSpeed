#!./php-cgi
<HTML>
<BODY>
   <?php phpinfo() ?>
</BODY>
</HTML>
